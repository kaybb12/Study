// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    onSnapshot,
    query, 
    orderBy, 
    limit } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCwWRJgfH4U8V_6ZbaEVmrL9lFtSlqCxbw",
  authDomain: "log-project-82f53.firebaseapp.com",
  projectId: "log-project-82f53",
  storageBucket: "log-project-82f53.appspot.com",
  messagingSenderId: "176891778891",
  appId: "1:176891778891:web:3e72540698922d57787ace"
};

// Firebase 초기화
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// 문자열에서 시간, hostname, log_level, log message 파싱
const parseLogEntry = (filename, line) => {
    const parts = line.split(' ');
        if (parts.length < 6) {
        return null;
    }
    return {
        filename: filename,
        timestamp: `${parts[0]} ${parts[1]} ${parts[2]}`,
        hostname: parts[3],
        log_level: parts[5].replace(':', ''),
        message: parts.slice(6).join(' ')
    };
};

// addDoc 함수를 이용하여 firestore 에 저장
const saveLogToFirestore = async (log) => {
    try {
        const docRef = await addDoc(collection(db, 'kernel_logs'), log);
        console.log('Log entry added with ID: ', docRef.id);
    } catch (error) {
        console.error('Error adding log entry: ', error);
    }
};

const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    const text = await file.text();
    const lines = text.split('\n');
    // 파일에서 로그 파싱
    const logs = lines.map(line => parseLogEntry(file.name, line)).filter(log => log !== null);
    for (const log of logs) {
        // firestore 에 저장
        await saveLogToFirestore(log);
    }
    console.log('All log entries have been uploaded.');
    alert('저장이 완료되었습니다.')
};
   
// 파일이 선택되었을 때의 이벤트 핸들러 추가
   
document.querySelector('#saveButton').addEventListener('change', handleFileUpload);  
const kernelLogsContainer = document.querySelector('.kernelLogs');

// 화면이 처음 로드될 때 데이터를 가져오는 함수
const loadAllLogs = async () => {
    const q = query(collection(db, 'kernel_logs'), orderBy('timestamp'));
    const querySnapshot = await getDocs(q);
    kernelLogsContainer.innerHTML = ''; // 기존 로그 초기화
            querySnapshot.forEach((doc) => {
            const log = doc.data();
            const filenameElement = document.createElement('div');
            filenameElement.classList.add('log-entry', 'filename');
            filenameElement.textContent = `${log.filename}`
            const logElement = document.createElement('div');
            logElement.classList.add('log-entry', 'log');
            const logLevelElement = document.createElement('span');
            logLevelElement.classList.add(log.log_level.toLowerCase());
            logLevelElement.textContent = `${log.log_level}: ${log.message}`;
            logElement.appendChild(document.createTextNode(`[ ${log.timestamp} ] ${log.hostname} kernel: `));
            logElement.appendChild(logLevelElement);
            kernelLogsContainer.appendChild(filenameElement);
            kernelLogsContainer.appendChild(logElement);
        });
};
 
await loadAllLogs();

// 실시간 업데이트 리스너 설정
const subscribeToRealTimeUpdates = () => {
    const q = query(collection(db, 'kernel_logs'), orderBy('timestamp'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
        kernelLogsContainer.innerHTML = ''; // 기존 로그 초기화
        snapshot.forEach((doc) => {
            const log = doc.data();
            const filenameElement = document.createElement('div');
            filenameElement.classList.add('log-entry', 'filename');
            filenameElement.textContent = `${log.filename}`
            const logElement = document.createElement('div');
            logElement.classList.add('log-entry', 'log');
            const logLevelElement = document.createElement('span');
            logLevelElement.classList.add(log.log_level.toLowerCase());
            logLevelElement.textContent = `${log.log_level}: ${log.message}`;

            logElement.appendChild(document.createTextNode(`[ ${log.timestamp} ] ${log.hostname} kernel: `));
            logElement.appendChild(logLevelElement);
            kernelLogsContainer.appendChild(filenameElement);
            kernelLogsContainer.appendChild(logElement);
        });
    });
};
   subscribeToRealTimeUpdates();

// 최근 10개의 로그를 가져오는 함수
const loadRecentLogs = async () => {
    const q = query(collection(db, 'kernel_logs'), orderBy('timestamp', 'desc'), limit(10));
    const querySnapshot = await getDocs(q);
    kernelLogsContainer.innerHTML = ''; // 기존 로그 초기화
    
    querySnapshot.forEach((doc) => {
        const log = doc.data();
            const filenameElement = document.createElement('div');
            filenameElement.classList.add('log-entry', 'filename');
            filenameElement.textContent = `${log.filename}`
            const logElement = document.createElement('div');
            logElement.classList.add('log-entry', 'log');
            const logLevelElement = document.createElement('span');
            logLevelElement.classList.add(log.log_level.toLowerCase());
            logLevelElement.textContent = `${log.log_level}: ${log.message}`;
            logElement.appendChild(document.createTextNode(`[ ${log.timestamp} ] ${log.hostname} kernel: `));
            logElement.appendChild(logLevelElement);
            kernelLogsContainer.appendChild(filenameElement);
            kernelLogsContainer.appendChild(logElement);
        });
   };
   
// 최근 10개 로그 버튼 클릭 이벤트 핸들러 추가
document.querySelector('#recentLogsButton').addEventListener('click', async () => {
    await loadRecentLogs();
});
   // 전체 로그 데이터를 가져올 수 있도록 이벤트 핸들러 추가
document.querySelector('#allLogsButton').addEventListener('click', async () => {
    await loadAllLogs();
});
   