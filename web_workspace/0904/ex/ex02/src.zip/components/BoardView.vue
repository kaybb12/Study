<script setup>

</script>

<template>
    <h1>Board</h1>
</template>

<style scoped>

</style>