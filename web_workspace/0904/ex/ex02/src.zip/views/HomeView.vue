<script setup>

import HomeHeader from "@/components/HomeHeader.vue";
import HomeMain from "@/components/HomeMain.vue";
import HomeFooter from "@/components/HomeFooter.vue";

</script>

<template>
    <h1>Home</h1>

    <HomeHeader></HomeHeader>
    <HomeMain></HomeMain>
    <HomeFooter></HomeFooter>
</template>

<style scoped>

</style>