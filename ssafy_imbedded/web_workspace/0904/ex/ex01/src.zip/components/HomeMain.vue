<script setup>
import HomeIcons from "@/components/HomeIcons.vue"; 

</script>

<template>
    <h2>HomeMain</h2>

    <HomeIcons></HomeIcons>
</template>

<style scoped>

</style>