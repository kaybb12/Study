<script setup>


</script>

<template>
    <h2>HomeFooter</h2>

    
</template>

<style scoped>

</style>