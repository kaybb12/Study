<script setup>

</script>

<template>
    <h1>Home</h1>
</template>

<style scoped>

</style>