<script setup>

</script>

<template>
    <h1>HomeIcons</h1>
</template>

<style scoped>

</style>