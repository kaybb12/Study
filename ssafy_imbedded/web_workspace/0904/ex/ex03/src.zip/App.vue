<script setup>
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
  <header>
      <nav>
        <RouterLink :to="{name : 'home' }">Home</RouterLink>
      </nav>
  </header>
  <RouterView />
</template>
